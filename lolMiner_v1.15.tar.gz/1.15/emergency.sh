#!/bin/bash

##################################
## Emergency script in case the ##
## miner crashes. User defined  ##
## actions to be inserted here  ##
##################################


